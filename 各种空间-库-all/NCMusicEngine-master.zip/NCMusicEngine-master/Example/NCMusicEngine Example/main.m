//
//  main.m
//  NCMusicEngine Example
//
//  Created by nickcheng on 13-1-23.
//  Copyright (c) 2013年 NC. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
  }
}
