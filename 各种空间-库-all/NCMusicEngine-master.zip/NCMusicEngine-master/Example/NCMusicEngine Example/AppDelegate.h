//
//  AppDelegate.h
//  NCMusicEngine Example
//
//  Created by nickcheng on 13-1-23.
//  Copyright (c) 2013年 NC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
